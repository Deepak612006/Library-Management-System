# Library Management System

A full working Flask + SQLite Library Management System aligned with the Software Engineering practicals.

## Features
- Admin and librarian login
- Dashboard
- Book CRUD
- Member CRUD
- Issue and return books
- Automatic due date (14 days)
- Automatic fine calculation (₹5/day late)
- Search
- Reports
- User management for admin
- JSON API endpoint
- Password hashing
- Role-based access control
- Responsive Bootstrap UI

## Demo accounts
- Admin: `admin` / `admin123`
- Librarian: `librarian` / `lib123`

Change these passwords before real deployment.

## Run on Windows

1. Install Python 3.
2. Open Command Prompt in this folder.
3. Run:
   `python -m venv venv`
4. Activate:
   `venv\Scripts\activate`
5. Install:
   `pip install -r requirements.txt`
6. Start:
   `python app.py`
7. Open:
   `http://127.0.0.1:5000`

The SQLite database `library.db` is created automatically on first run.

## Practical coverage

P1 Requirement Engineering
P2 Agile Model / Implementation
P3 SRS
P4 SPMP
P5 Cost & Effort Estimation
P6 Risk Management
P7 Architecture & Design
P8 Coding Standards / Modular Implementation
P9 Test Cases
P10 Testing Tools / API endpoint
P11 Security & Quality

## Production notes
- Replace `app.secret_key`.
- Use HTTPS.
- Use a production WSGI server.
- Move credentials/secrets to environment variables.
- For a college demo, SQLite is intentionally used so the project runs without a separate database server.
