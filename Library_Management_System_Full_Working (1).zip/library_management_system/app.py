from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from functools import wraps
from datetime import date, timedelta, datetime
from pathlib import Path

app = Flask(__name__)
app.secret_key = "lms-development-secret-change-me"
DB = Path(__file__).with_name("library.db")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'librarian'
    );
    CREATE TABLE IF NOT EXISTS books(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        isbn TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        publisher TEXT,
        category TEXT,
        quantity INTEGER NOT NULL DEFAULT 1,
        available INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        department TEXT,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id INTEGER NOT NULL,
        member_id INTEGER NOT NULL,
        issue_date TEXT NOT NULL,
        due_date TEXT NOT NULL,
        return_date TEXT,
        fine REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Issued',
        FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE RESTRICT,
        FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE RESTRICT
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        conn.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                     ("admin", generate_password_hash("admin123"), "admin"))
        conn.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                     ("librarian", generate_password_hash("lib123"), "librarian"))
    if conn.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
        sample = [
            ("9780132350884","Clean Code","Robert C. Martin","Prentice Hall","Programming",3,3),
            ("9780262033848","Introduction to Algorithms","Cormen et al.","MIT Press","Algorithms",2,2),
            ("9780131103627","The C Programming Language","Kernighan & Ritchie","Prentice Hall","Programming",2,2),
            ("9781491950357","Fluent Python","Luciano Ramalho","O'Reilly","Python",2,2)
        ]
        conn.executemany("""INSERT INTO books(isbn,title,author,publisher,category,quantity,available)
                            VALUES(?,?,?,?,?,?,?)""", sample)
    if conn.execute("SELECT COUNT(*) FROM members").fetchone()[0] == 0:
        conn.execute("""INSERT INTO members(name,email,phone,department,created_at)
                        VALUES(?,?,?,?,?)""",
                     ("Demo Student","student@example.com","9876543210","CSE",date.today().isoformat()))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapped

def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_globals():
    return {"today": date.today().isoformat()}

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            flash("Login successful.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    stats = {
        "books": conn.execute("SELECT COALESCE(SUM(quantity),0) FROM books").fetchone()[0],
        "available": conn.execute("SELECT COALESCE(SUM(available),0) FROM books").fetchone()[0],
        "members": conn.execute("SELECT COUNT(*) FROM members").fetchone()[0],
        "issued": conn.execute("SELECT COUNT(*) FROM transactions WHERE status='Issued'").fetchone()[0],
        "fines": conn.execute("SELECT COALESCE(SUM(fine),0) FROM transactions").fetchone()[0],
    }
    recent = conn.execute("""SELECT t.*, b.title, m.name
                            FROM transactions t
                            JOIN books b ON b.id=t.book_id
                            JOIN members m ON m.id=t.member_id
                            ORDER BY t.id DESC LIMIT 8""").fetchall()
    conn.close()
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/books")
@login_required
def books():
    q = request.args.get("q","").strip()
    conn = get_db()
    if q:
        rows = conn.execute("""SELECT * FROM books
            WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ?
            ORDER BY title""", tuple(f"%{q}%" for _ in range(4))).fetchall()
    else:
        rows = conn.execute("SELECT * FROM books ORDER BY title").fetchall()
    conn.close()
    return render_template("books.html", books=rows, q=q)

@app.route("/books/add", methods=["GET","POST"])
@login_required
def add_book():
    if request.method == "POST":
        data = {k: request.form.get(k,"").strip() for k in ["isbn","title","author","publisher","category"]}
        try:
            qty = max(1, int(request.form.get("quantity","1")))
            conn = get_db()
            conn.execute("""INSERT INTO books(isbn,title,author,publisher,category,quantity,available)
                            VALUES(?,?,?,?,?,?,?)""",
                         (*data.values(), qty, qty))
            conn.commit(); conn.close()
            flash("Book added successfully.", "success")
            return redirect(url_for("books"))
        except Exception as e:
            flash("Could not add book. ISBN may already exist.", "danger")
    return render_template("book_form.html", book=None)

@app.route("/books/<int:book_id>/edit", methods=["GET","POST"])
@login_required
def edit_book(book_id):
    conn = get_db()
    book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not book:
        conn.close(); flash("Book not found.", "danger"); return redirect(url_for("books"))
    if request.method == "POST":
        try:
            qty = max(1, int(request.form.get("quantity","1")))
            issued = book["quantity"] - book["available"]
            if qty < issued:
                flash(f"Quantity cannot be less than currently issued copies ({issued}).", "danger")
            else:
                available = qty - issued
                conn.execute("""UPDATE books SET isbn=?,title=?,author=?,publisher=?,category=?,quantity=?,available=?
                                WHERE id=?""",
                             (request.form["isbn"].strip(), request.form["title"].strip(),
                              request.form["author"].strip(), request.form.get("publisher","").strip(),
                              request.form.get("category","").strip(), qty, available, book_id))
                conn.commit(); conn.close()
                flash("Book updated.", "success")
                return redirect(url_for("books"))
        except Exception:
            flash("Unable to update book.", "danger")
    conn.close()
    return render_template("book_form.html", book=book)

@app.route("/books/<int:book_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_book(book_id):
    conn = get_db()
    try:
        conn.execute("DELETE FROM books WHERE id=?", (book_id,))
        conn.commit()
        flash("Book deleted.", "success")
    except sqlite3.IntegrityError:
        flash("Book cannot be deleted because it has transaction history.", "danger")
    finally:
        conn.close()
    return redirect(url_for("books"))

@app.route("/members")
@login_required
def members():
    q = request.args.get("q","").strip()
    conn = get_db()
    if q:
        rows = conn.execute("""SELECT * FROM members WHERE name LIKE ? OR email LIKE ? OR department LIKE ?
                              ORDER BY name""", (f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    conn.close()
    return render_template("members.html", members=rows, q=q)

@app.route("/members/add", methods=["GET","POST"])
@login_required
def add_member():
    if request.method == "POST":
        name=request.form.get("name","").strip()
        if not name:
            flash("Name is required.", "danger")
            return render_template("member_form.html", member=None)
        conn=get_db()
        conn.execute("""INSERT INTO members(name,email,phone,department,created_at)
                        VALUES(?,?,?,?,?)""",
                     (name,request.form.get("email","").strip(),request.form.get("phone","").strip(),
                      request.form.get("department","").strip(),date.today().isoformat()))
        conn.commit(); conn.close()
        flash("Member added successfully.", "success")
        return redirect(url_for("members"))
    return render_template("member_form.html", member=None)

@app.route("/members/<int:member_id>/edit", methods=["GET","POST"])
@login_required
def edit_member(member_id):
    conn=get_db(); member=conn.execute("SELECT * FROM members WHERE id=?", (member_id,)).fetchone()
    if not member:
        conn.close(); flash("Member not found.","danger"); return redirect(url_for("members"))
    if request.method=="POST":
        conn.execute("""UPDATE members SET name=?,email=?,phone=?,department=? WHERE id=?""",
                     (request.form["name"].strip(),request.form.get("email","").strip(),
                      request.form.get("phone","").strip(),request.form.get("department","").strip(),member_id))
        conn.commit(); conn.close(); flash("Member updated.","success")
        return redirect(url_for("members"))
    conn.close(); return render_template("member_form.html", member=member)

@app.route("/members/<int:member_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_member(member_id):
    conn=get_db()
    try:
        conn.execute("DELETE FROM members WHERE id=?", (member_id,)); conn.commit()
        flash("Member deleted.","success")
    except sqlite3.IntegrityError:
        flash("Member cannot be deleted because transaction history exists.","danger")
    finally: conn.close()
    return redirect(url_for("members"))

@app.route("/transactions")
@login_required
def transactions():
    conn=get_db()
    rows=conn.execute("""SELECT t.*,b.title,m.name
                         FROM transactions t JOIN books b ON b.id=t.book_id
                         JOIN members m ON m.id=t.member_id
                         ORDER BY t.id DESC""").fetchall()
    conn.close()
    return render_template("transactions.html", transactions=rows)

@app.route("/issue", methods=["GET","POST"])
@login_required
def issue_book():
    conn=get_db()
    if request.method=="POST":
        book_id=int(request.form["book_id"]); member_id=int(request.form["member_id"])
        book=conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
        member=conn.execute("SELECT * FROM members WHERE id=?", (member_id,)).fetchone()
        if not book or not member:
            flash("Invalid book or member.","danger")
        elif book["available"] <= 0:
            flash("Book is currently unavailable.","danger")
        else:
            issue=date.today(); due=issue+timedelta(days=14)
            conn.execute("""INSERT INTO transactions(book_id,member_id,issue_date,due_date,status)
                            VALUES(?,?,?,?,?)""",(book_id,member_id,issue.isoformat(),due.isoformat(),"Issued"))
            conn.execute("UPDATE books SET available=available-1 WHERE id=?", (book_id,))
            conn.commit(); conn.close()
            flash(f"Book issued. Due date: {due.isoformat()}", "success")
            return redirect(url_for("transactions"))
    books=conn.execute("SELECT * FROM books WHERE available>0 ORDER BY title").fetchall()
    members=conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    conn.close()
    return render_template("issue.html", books=books, members=members)

@app.route("/return/<int:transaction_id>", methods=["POST"])
@login_required
def return_book(transaction_id):
    conn=get_db()
    t=conn.execute("SELECT * FROM transactions WHERE id=?", (transaction_id,)).fetchone()
    if not t or t["status"]=="Returned":
        conn.close(); flash("Transaction already returned or not found.","warning"); return redirect(url_for("transactions"))
    today=date.today()
    due=date.fromisoformat(t["due_date"])
    late=max(0,(today-due).days)
    fine=late*5.0
    conn.execute("""UPDATE transactions SET return_date=?,fine=?,status='Returned' WHERE id=?""",
                 (today.isoformat(),fine,transaction_id))
    conn.execute("UPDATE books SET available=available+1 WHERE id=?", (t["book_id"],))
    conn.commit(); conn.close()
    flash(f"Book returned. Fine: ₹{fine:.2f}", "success")
    return redirect(url_for("transactions"))

@app.route("/reports")
@login_required
def reports():
    conn=get_db()
    category=conn.execute("""SELECT COALESCE(category,'Uncategorized') category,
                             SUM(quantity) total, SUM(available) available
                             FROM books GROUP BY category ORDER BY category""").fetchall()
    overdue=conn.execute("""SELECT t.*,b.title,m.name FROM transactions t
                            JOIN books b ON b.id=t.book_id JOIN members m ON m.id=t.member_id
                            WHERE t.status='Issued' AND date(t.due_date)<date('now')
                            ORDER BY t.due_date""").fetchall()
    fines=conn.execute("""SELECT COALESCE(SUM(fine),0) total,
                                 COALESCE(SUM(CASE WHEN fine>0 THEN 1 ELSE 0 END),0) count
                          FROM transactions""").fetchone()
    conn.close()
    return render_template("reports.html", category=category, overdue=overdue, fines=fines)

@app.route("/api/books")
@login_required
def api_books():
    conn=get_db()
    rows=conn.execute("SELECT id,isbn,title,author,available,quantity FROM books ORDER BY title").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/users", methods=["GET","POST"])
@login_required
@admin_required
def users():
    conn=get_db()
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        role=request.form.get("role","librarian")
        try:
            conn.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                         (username,generate_password_hash(password),role))
            conn.commit(); flash("User created.","success")
        except sqlite3.IntegrityError:
            flash("Username already exists.","danger")
    rows=conn.execute("SELECT id,username,role FROM users ORDER BY username").fetchall()
    conn.close()
    return render_template("users.html", users=rows)

@app.route("/users/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot delete your own account.","danger")
        return redirect(url_for("users"))
    conn=get_db(); conn.execute("DELETE FROM users WHERE id=?", (user_id,)); conn.commit(); conn.close()
    flash("User deleted.","success"); return redirect(url_for("users"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
